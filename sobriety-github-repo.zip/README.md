# Sobriety App 🌱

Un'app per tracciare il tuo percorso verso la sobrietà. Empatica, senza giudizi, sempre al tuo fianco.

## Funzionalità

### 🏠 Home
- Timer di sobrietà
- Obiettivi personalizzabili (settimane/mesi)
- Barra di progresso
- Citazioni motivazionali
- Riepilogo settimanale

### 📝 Check-in Giornaliero
- Traccia il tuo umore
- Registra la difficoltà della giornata
- Annota cosa hai fatto e chi hai incontrato
- Spazio per le tue riflessioni
- Gestione empatica delle ricadute

### 📔 Diario
- Cronologia completa dei check-in
- Visualizza i tuoi progressi nel tempo

### 📊 Statistiche
- Tempo totale sobrio
- Giorni consecutivi
- Analisi settimanale intelligente
- Pattern e tendenze

### 🔍 Scopri
- Benefici della sobrietà (da 24h a 1 anno)
- Ricette mocktail

## Installazione

### Opzione 1: Netlify (consigliato)
1. Fai fork di questo repository
2. Vai su [netlify.com](https://netlify.com)
3. Clicca "Add new site" → "Import an existing project"
4. Connetti il tuo GitHub e seleziona questo repo
5. Deploy automatico!

### Opzione 2: Qualsiasi hosting statico
Carica tutti i file nella root del tuo hosting.

## Installazione come App

Una volta online:

**iPhone/iPad:**
1. Apri il sito in Safari
2. Tap su "Condividi" (icona quadrato con freccia)
3. Scorri e tap "Aggiungi a Home"

**Android:**
1. Apri il sito in Chrome
2. Tap menu (⋮)
3. Tap "Installa app" o "Aggiungi a schermata Home"

## Privacy

Tutti i dati sono salvati **localmente** nel tuo browser. Nessun dato viene inviato a server esterni. I tuoi check-in, il diario e le statistiche restano solo tuoi.

## Aggiornamenti

Per aggiornare l'app:
1. Modifica i file
2. Fai commit e push su GitHub
3. Netlify aggiorna automaticamente

## Tecnologie

- HTML5
- CSS3
- JavaScript (Vanilla)
- PWA (Progressive Web App)
- LocalStorage per persistenza dati

## Licenza

MIT - Usa, modifica e condividi liberamente.

---

*Un giorno alla volta.* 💚
